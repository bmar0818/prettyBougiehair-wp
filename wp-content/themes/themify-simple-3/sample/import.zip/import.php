<?php

defined( 'ABSPATH' ) or die;

$GLOBALS['processed_terms'] = array();
$GLOBALS['processed_posts'] = array();

require_once ABSPATH . 'wp-admin/includes/post.php';
require_once ABSPATH . 'wp-admin/includes/taxonomy.php';
require_once ABSPATH . 'wp-admin/includes/image.php';

/**
 * Add an Import Action, this data is stored for processing after import is done.
 *
 * Each action is sent as an Ajax request and is handled by themify-ajax.php file
 */ 
function themify_add_import_action( $action = '', $data = array() ) {
	global $import_actions;

	if ( ! isset( $import_actions[ $action ] ) ) {
		$import_actions[ $action ] = array();
	}

	$import_actions[ $action ][] = $data;
}

function themify_import_post( $post ) {
	global $processed_posts, $processed_terms;

	if ( ! post_type_exists( $post['post_type'] ) ) {
		return;
	}

	/* Menu items don't have reliable post_title, skip the post_exists check */
	if( $post['post_type'] !== 'nav_menu_item' ) {
		$post_exists = post_exists( $post['post_title'], '', $post['post_date'] );
		if ( $post_exists && get_post_type( $post_exists ) == $post['post_type'] ) {
			$processed_posts[ intval( $post['ID'] ) ] = intval( $post_exists );
			return;
		}
	}

	if( $post['post_type'] == 'nav_menu_item' ) {
		if( ! isset( $post['tax_input']['nav_menu'] ) || ! term_exists( $post['tax_input']['nav_menu'], 'nav_menu' ) ) {
			return;
		}
		$_menu_item_type = $post['meta_input']['_menu_item_type'];
		$_menu_item_object_id = $post['meta_input']['_menu_item_object_id'];

		if ( 'taxonomy' == $_menu_item_type && isset( $processed_terms[ intval( $_menu_item_object_id ) ] ) ) {
			$post['meta_input']['_menu_item_object_id'] = $processed_terms[ intval( $_menu_item_object_id ) ];
		} else if ( 'post_type' == $_menu_item_type && isset( $processed_posts[ intval( $_menu_item_object_id ) ] ) ) {
			$post['meta_input']['_menu_item_object_id'] = $processed_posts[ intval( $_menu_item_object_id ) ];
		} else if ( 'custom' != $_menu_item_type ) {
			// associated object is missing or not imported yet, we'll retry later
			// $missing_menu_items[] = $item;
			return;
		}
	}

	$post_parent = ( $post['post_type'] == 'nav_menu_item' ) ? $post['meta_input']['_menu_item_menu_item_parent'] : (int) $post['post_parent'];
	$post['post_parent'] = 0;
	if ( $post_parent ) {
		// if we already know the parent, map it to the new local ID
		if ( isset( $processed_posts[ $post_parent ] ) ) {
			if( $post['post_type'] == 'nav_menu_item' ) {
				$post['meta_input']['_menu_item_menu_item_parent'] = $processed_posts[ $post_parent ];
			} else {
				$post['post_parent'] = $processed_posts[ $post_parent ];
			}
		}
	}

	/**
	 * for hierarchical taxonomies, IDs must be used so wp_set_post_terms can function properly
	 * convert term slugs to IDs for hierarchical taxonomies
	 */
	if( ! empty( $post['tax_input'] ) ) {
		foreach( $post['tax_input'] as $tax => $terms ) {
			if( is_taxonomy_hierarchical( $tax ) ) {
				$terms = explode( ', ', $terms );
				$post['tax_input'][ $tax ] = array_map( 'themify_get_term_id_by_slug', $terms, array_fill( 0, count( $terms ), $tax ) );
			}
		}
	}

	$post['post_author'] = (int) get_current_user_id();
	$post['post_status'] = 'publish';

	$old_id = $post['ID'];

	unset( $post['ID'] );
	$post_id = wp_insert_post( $post, true );
	if( is_wp_error( $post_id ) ) {
		return false;
	} else {
		$processed_posts[ $old_id ] = $post_id;

		return $post_id;
	}
}

function themify_get_placeholder_image() {
	static $placeholder_image = null;

	if( $placeholder_image == null ) {
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();
		global $wp_filesystem;
		$upload = wp_upload_bits( $post['post_name'] . '.jpg', null, $wp_filesystem->get_contents( THEMIFY_DIR . '/img/image-placeholder.jpg' ) );

		if ( $info = wp_check_filetype( $upload['file'] ) )
			$post['post_mime_type'] = $info['type'];
		else
			return new WP_Error( 'attachment_processing_error', __( 'Invalid file type', 'themify' ) );

		$post['guid'] = $upload['url'];
		$post_id = wp_insert_attachment( $post, $upload['file'] );
		wp_update_attachment_metadata( $post_id, wp_generate_attachment_metadata( $post_id, $upload['file'] ) );

		$placeholder_image = $post_id;
	}

	return $placeholder_image;
}

function themify_import_term( $term ) {
	global $processed_terms;

	if( $term_id = term_exists( $term['slug'], $term['taxonomy'] ) ) {
		if ( is_array( $term_id ) ) $term_id = $term_id['term_id'];
		if ( isset( $term['term_id'] ) )
			$processed_terms[ intval( $term['term_id'] ) ] = (int) $term_id;
		return (int) $term_id;
	}

	if ( empty( $term['parent'] ) ) {
		$parent = 0;
	} else {
		$parent = term_exists( $processed_terms[ intval( $term['parent'] ) ], $term['taxonomy'] );
		if ( is_array( $parent ) ) $parent = $parent['term_id'];
	}

	$id = wp_insert_term( $term['name'], $term['taxonomy'], array(
		'parent' => $parent,
		'slug' => $term['slug'],
		'description' => $term['description'],
	) );
	if ( ! is_wp_error( $id ) ) {
		if ( isset( $term['term_id'] ) ) {
			// success!
			$processed_terms[ intval($term['term_id']) ] = $id['term_id'];
			if ( isset( $term['thumbnail'] ) ) {
				themify_add_import_action( 'term_thumb', array(
					'id' => $id['term_id'],
					'thumb' => $term['thumbnail'],
				) );
			}
			return $term['term_id'];
		}
	}

	return false;
}

function themify_get_term_id_by_slug( $slug, $tax ) {
	$term = get_term_by( 'slug', $slug, $tax );
	if( $term ) {
		return $term->term_id;
	}

	return false;
}

function themify_undo_import_term( $term ) {
	$term_id = term_exists( $term['slug'], $term['taxonomy'] );
	if ( $term_id ) {
		if ( is_array( $term_id ) ) $term_id = $term_id['term_id'];

		if ( $term_thumbnail = get_term_meta( $term['term_id'], 'thumbnail_id', true ) ) {
			wp_delete_attachment( $term_thumbnail, true );
		}

		if ( isset( $term_id ) ) {
			wp_delete_term( $term_id, $term['taxonomy'] );
		}
	}
}

/**
 * Determine if a post exists based on title, content, and date
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param array $args array of database parameters to check
 * @return int Post ID if post exists, 0 otherwise.
 */
function themify_post_exists( $args = array() ) {
	global $wpdb;

	$query = "SELECT ID FROM $wpdb->posts WHERE 1=1";
	$db_args = array();

	foreach ( $args as $key => $value ) {
		$value = wp_unslash( sanitize_post_field( $key, $value, 0, 'db' ) );
		if( ! empty( $value ) ) {
			$query .= ' AND ' . $key . ' = %s';
			$db_args[] = $value;
		}
	}

	if ( !empty ( $args ) )
		return (int) $wpdb->get_var( $wpdb->prepare($query, $args) );

	return 0;
}

function themify_undo_import_post( $post ) {
	if( $post['post_type'] == 'nav_menu_item' ) {
		$post_exists = themify_post_exists( array(
			'post_name' => $post['post_name'],
			'post_modified' => $post['post_date'],
			'post_type' => 'nav_menu_item',
		) );
	} else {
		$post_exists = post_exists( $post['post_title'], '', $post['post_date'] );
	}
	if( $post_exists && get_post_type( $post_exists ) == $post['post_type'] ) {
		/**
		 * check if the post has been modified, if so leave it be
		 *
		 * NOTE: posts are imported using wp_insert_post() which modifies post_modified field
		 * to be the same as post_date, hence to check if the post has been modified,
		 * the post_modified field is compared against post_date in the original post.
		 */
		if( $post['post_date'] == get_post_field( 'post_modified', $post_exists ) ) {
			// find and remove all post attachments
			$attachments = get_posts( array(
				'post_type' => 'attachment',
				'posts_per_page' => -1,
				'post_parent' => $post_exists,
			) );
			if ( $attachments ) {
				foreach ( $attachments as $attachment ) {
					wp_delete_attachment( $attachment->ID, true );
				}
			}
			wp_delete_post( $post_exists, true ); // true: bypass trash
		}
	}
}

function themify_process_post_import( $post ) {
	if( ERASEDEMO ) {
		themify_undo_import_post( $post );
	} else {
		if ( $id = themify_import_post( $post ) ) {
			if ( defined( 'IMPORT_IMAGES' ) && ! IMPORT_IMAGES ) {
				/* if importing images is disabled and post is supposed to have a thumbnail, create a placeholder image instead */
				if ( isset( $post['thumb'] ) ) { // the post is supposed to have featured image
					$placeholder = themify_get_placeholder_image();
					if( ! is_wp_error( $placeholder ) ) {
						set_post_thumbnail( $id, $placeholder );
					}
				}
			} else {
				if ( isset( $post["thumb"] ) ) {
					themify_add_import_action( 'post_thumb', array(
						'id' => $id,
						'thumb' => $post["thumb"],
					) );
				}
				if ( isset( $post["gallery_shortcode"] ) ) {
					themify_add_import_action( 'gallery_field', array(
						'id' => $id,
						'fields' => $post["gallery_shortcode"],
					) );
				}
			}
		}
	}
}
$thumbs = array();
function themify_do_demo_import() {
global $import_actions;

	if ( isset( $GLOBALS["ThemifyBuilder_Data_Manager"] ) ) {
		remove_action( "save_post", array( $GLOBALS["ThemifyBuilder_Data_Manager"], "save_builder_text_only"), 10, 3 );
	}
$term = array (
  'term_id' => 2,
  'name' => 'Fashion',
  'slug' => 'fashion',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => 'All About Fashion',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 4,
  'name' => 'Technology',
  'slug' => 'technology',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => 'All About Tech News',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 5,
  'name' => 'Accessories',
  'slug' => 'accessories',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => 'Fashion Accessories For Women',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 6,
  'name' => 'Fashion Event',
  'slug' => 'fashion-event',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => 'Fashion Event Info',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 3,
  'name' => 'Fashion',
  'slug' => 'fashion',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 8,
  'name' => 'Event',
  'slug' => 'event',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 9,
  'name' => 'Exhibition',
  'slug' => 'exhibition',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 10,
  'name' => 'Trend',
  'slug' => 'trend',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 11,
  'name' => 'Mode',
  'slug' => 'mode',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 12,
  'name' => 'Eyeglass',
  'slug' => 'eyeglass',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 13,
  'name' => 'Accessories',
  'slug' => 'accessories',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 14,
  'name' => 'Technology',
  'slug' => 'technology',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 15,
  'name' => 'Photography',
  'slug' => 'photography',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 16,
  'name' => 'gadget',
  'slug' => 'gadget',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 17,
  'name' => 'Apple',
  'slug' => 'apple',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 18,
  'name' => 'iMac',
  'slug' => 'imac',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 19,
  'name' => 'Gadgets',
  'slug' => 'gadgets',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 20,
  'name' => 'Collection',
  'slug' => 'collection',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 21,
  'name' => 'Designer',
  'slug' => 'designer',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 7,
  'name' => 'Main Menu',
  'slug' => 'main-menu',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$post = array (
  'ID' => 57,
  'post_date' => '2016-02-19 06:24:02',
  'post_date_gmt' => '2016-02-19 06:24:02',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'post_title' => 'NYC Fashion Event',
  'post_excerpt' => '',
  'post_name' => 'nyc-fashion-event',
  'post_modified' => '2017-08-23 03:12:12',
  'post_modified_gmt' => '2017-08-23 03:12:12',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=57',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion-event',
    'post_tag' => 'exhibition',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/99449315.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 4,
  'post_date' => '2016-02-19 01:26:35',
  'post_date_gmt' => '2016-02-19 01:26:35',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Red Carpet Fashion',
  'post_excerpt' => '',
  'post_name' => 'fashion',
  'post_modified' => '2017-08-23 03:12:32',
  'post_modified_gmt' => '2017-08-23 03:12:32',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=4',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar1',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'fashion, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/57284001.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 7,
  'post_date' => '2016-02-19 01:28:30',
  'post_date_gmt' => '2016-02-19 01:28:30',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Summer Collection',
  'post_excerpt' => '',
  'post_name' => 'summer-collection',
  'post_modified' => '2017-08-23 03:12:30',
  'post_modified_gmt' => '2017-08-23 03:12:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=7',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'default',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'mode, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/95135980.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 11,
  'post_date' => '2016-02-19 02:14:06',
  'post_date_gmt' => '2016-02-19 02:14:06',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Casual Outfits',
  'post_excerpt' => '',
  'post_name' => 'casual-outfits',
  'post_modified' => '2017-08-23 03:12:29',
  'post_modified_gmt' => '2017-08-23 03:12:29',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=11',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'fashion, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/girl-410334_1920.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 14,
  'post_date' => '2016-02-19 02:23:24',
  'post_date_gmt' => '2016-02-19 02:23:24',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => '7 Things We Learned About Spring Dressing',
  'post_excerpt' => '',
  'post_name' => '7-things-we-learned-about-spring-dressing',
  'post_modified' => '2017-08-23 03:12:27',
  'post_modified_gmt' => '2017-08-23 03:12:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=14',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'mode, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/148328327.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 17,
  'post_date' => '2016-02-19 06:28:47',
  'post_date_gmt' => '2016-02-19 06:28:47',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => '2106 Fashion Trends for Teen',
  'post_excerpt' => '',
  'post_name' => '2106-fashion-trends-for-teen',
  'post_modified' => '2017-08-23 03:12:10',
  'post_modified_gmt' => '2017-08-23 03:12:10',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=17',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'event, exhibition, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/179211281.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 20,
  'post_date' => '2016-02-19 02:40:18',
  'post_date_gmt' => '2016-02-19 02:40:18',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Must Have Gadgets',
  'post_excerpt' => '',
  'post_name' => 'must-have-gadgets',
  'post_modified' => '2017-08-23 03:12:25',
  'post_modified_gmt' => '2017-08-23 03:12:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=20',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'technology',
    'post_tag' => 'gadgets, technology',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/iPad-Air-2.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 23,
  'post_date' => '2016-02-19 02:44:22',
  'post_date_gmt' => '2016-02-19 02:44:22',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'post_title' => 'iMac 27-inch sizes Now Available',
  'post_excerpt' => '',
  'post_name' => 'imac',
  'post_modified' => '2017-08-23 03:12:23',
  'post_modified_gmt' => '2017-08-23 03:12:23',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=23',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'technology',
    'post_tag' => 'apple, imac, technology',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/og_image.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 26,
  'post_date' => '2016-02-19 04:17:38',
  'post_date_gmt' => '2016-02-19 04:17:38',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Smart Watch Released',
  'post_excerpt' => '',
  'post_name' => 'smart-watch-new-color',
  'post_modified' => '2017-08-23 03:12:22',
  'post_modified_gmt' => '2017-08-23 03:12:22',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=26',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'technology',
    'post_tag' => 'gadget, technology',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/product-page-6.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 30,
  'post_date' => '2016-02-19 04:18:38',
  'post_date_gmt' => '2016-02-19 04:18:38',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Spring Photography',
  'post_excerpt' => '',
  'post_name' => 'spring-photography',
  'post_modified' => '2017-08-23 03:12:20',
  'post_modified_gmt' => '2017-08-23 03:12:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=30',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'mode, photography',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/67088788.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 37,
  'post_date' => '2016-02-19 04:21:44',
  'post_date_gmt' => '2016-02-19 04:21:44',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Super Computer With Super Specs',
  'post_excerpt' => '',
  'post_name' => 'super-computer-with-super-specs',
  'post_modified' => '2017-08-23 03:12:18',
  'post_modified_gmt' => '2017-08-23 03:12:18',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=37',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'technology',
    'post_tag' => 'technology',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/comingsoon.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 40,
  'post_date' => '2016-02-19 04:28:38',
  'post_date_gmt' => '2016-02-19 04:28:38',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur',
  'post_title' => 'Pearl Necklace',
  'post_excerpt' => '',
  'post_name' => 'pearl-necklace',
  'post_modified' => '2017-08-23 03:12:17',
  'post_modified_gmt' => '2017-08-23 03:12:17',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=40',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'accessories',
    'post_tag' => 'accessories, mode',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/69030349.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 45,
  'post_date' => '2016-02-19 04:33:05',
  'post_date_gmt' => '2016-02-19 04:33:05',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum',
  'post_title' => 'Eyeglass For Girls',
  'post_excerpt' => '',
  'post_name' => 'eyeglass-collection',
  'post_modified' => '2017-08-23 03:12:15',
  'post_modified_gmt' => '2017-08-23 03:12:15',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=45',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'accessories',
    'post_tag' => 'eyeglass, mode, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/194510450.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 48,
  'post_date' => '2015-12-19 04:38:20',
  'post_date_gmt' => '2015-12-19 04:38:20',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Ultimate Woman Bags Collections',
  'post_excerpt' => '',
  'post_name' => 'ultimate-woman-bags-collections',
  'post_modified' => '2017-08-23 03:12:37',
  'post_modified_gmt' => '2017-08-23 03:12:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=48',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'accessories',
    'post_tag' => 'accessories, mode',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/leather-1175154_1920.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 51,
  'post_date' => '2015-11-14 04:43:16',
  'post_date_gmt' => '2015-11-14 04:43:16',
  'post_content' => 'Qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'post_title' => 'Must Have Accessories',
  'post_excerpt' => '',
  'post_name' => 'must-have-accessories',
  'post_modified' => '2017-08-23 03:12:38',
  'post_modified_gmt' => '2017-08-23 03:12:38',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=51',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'accessories',
    'post_tag' => 'accessories, mode',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/beads-776102_1920.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 54,
  'post_date' => '2016-02-19 04:50:05',
  'post_date_gmt' => '2016-02-19 04:50:05',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => '80\' Collection',
  'post_excerpt' => '',
  'post_name' => '80-collection',
  'post_modified' => '2017-08-23 03:12:13',
  'post_modified_gmt' => '2017-08-23 03:12:13',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=54',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'accessories',
    'post_tag' => 'mode, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/59553262.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 61,
  'post_date' => '2016-01-02 06:25:55',
  'post_date_gmt' => '2016-01-02 06:25:55',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque',
  'post_title' => 'Winter Collection By Top Designers',
  'post_excerpt' => '',
  'post_name' => 'winter-collection-by-top-designers',
  'post_modified' => '2017-08-23 03:12:35',
  'post_modified_gmt' => '2017-08-23 03:12:35',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=61',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion-event',
    'post_tag' => 'collection, designer, mode',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/93501982.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 64,
  'post_date' => '2016-02-19 06:33:30',
  'post_date_gmt' => '2016-02-19 06:33:30',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat',
  'post_title' => 'Spring Fashion Event',
  'post_excerpt' => '',
  'post_name' => 'spring-fashion-event',
  'post_modified' => '2017-08-23 03:12:05',
  'post_modified_gmt' => '2017-08-23 03:12:05',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=64',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion-event',
    'post_tag' => 'event',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/54153043.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 66,
  'post_date' => '2016-02-19 06:49:58',
  'post_date_gmt' => '2016-02-19 06:49:58',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Summer Fashion Exhibition',
  'post_excerpt' => '',
  'post_name' => 'summer-fashion-exhibition',
  'post_modified' => '2017-08-23 03:12:08',
  'post_modified_gmt' => '2017-08-23 03:12:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=66',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion-event',
    'post_tag' => 'event, exhibition',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/148512749.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 69,
  'post_date' => '2016-02-17 07:11:58',
  'post_date_gmt' => '2016-02-17 07:11:58',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Retro Fashion Week',
  'post_excerpt' => '',
  'post_name' => 'retro-fashion-week',
  'post_modified' => '2017-08-23 03:12:33',
  'post_modified_gmt' => '2017-08-23 03:12:33',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=69',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'content_width' => 'default_width',
    'layout' => 'sidebar-none',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion-event',
    'post_tag' => 'event',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/147293620.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 90,
  'post_date' => '2016-02-19 13:55:54',
  'post_date_gmt' => '2016-02-19 13:55:54',
  'post_content' => '<!--themify_builder_static--><h1>Shopify + Themify </h1><p>Simple is a free theme to make Shopify ecommerce sites with WordPress.</p> 
 <p>[themify_button link="https://themify.me/themes/simple" style="large rounded white outline"]Download[/themify_button]</p> 
 <a href="#products"> </a> 
 <img src="https://themify.me/demo/themes/simple/files/2016/02/ripped-jeans-445x348.png" width="445" alt="ripped jeans" srcset="https://themify.me/demo/themes/simple/files/2016/02/ripped-jeans.png 445w, https://themify.me/demo/themes/simple/files/2016/02/ripped-jeans-300x235.png 300w" sizes="(max-width: 445px) 100vw, 445px" /> 
 <h2 style="text-align: left;">Ripped Jeans</h2><p style="text-align: left;">Cras non ultricies nulla, quis varius orci. Nulla ac pellentesque eros, eu interdum leo. Phasellus non dui viverra, consectetur mauris ac, pharetra massa.</p><p style="text-align: left;">[shopify_buy_button shop="themifytest.myshopify.com" embed_type="product" handle="ripped-jeans" has_image="false" has_modal="false" redirect_to="cart" buy_button_text="Add To Cart" button_background_color="03c6ad" button_text_color="ffffff"]</p> 
 <img src="https://themify.me/demo/themes/simple/files/2016/02/smartwatch-315x271.png" width="315" alt="smartwatch" srcset="https://themify.me/demo/themes/simple/files/2016/02/smartwatch-315x271.png 315w, https://themify.me/demo/themes/simple/files/2016/02/smartwatch-300x258.png 300w, https://themify.me/demo/themes/simple/files/2016/02/smartwatch-445x383.png 445w, https://themify.me/demo/themes/simple/files/2016/02/smartwatch.png 316w" sizes="(max-width: 315px) 100vw, 315px" /> 
 <h2>Smart Watch</h2><p>Epretium condimentum tiam fermentum condimentum elit ac accumsan. Proin cursus, lectus malesuada , quam odio malesuada purus, et sodales diam erat velest.</p><p>[shopify_buy_button shop="themifytest.myshopify.com" embed_type="product" handle="smart-watch" has_image="false" has_modal="false" redirect_to="checkout" buy_button_text="Buy Now" button_background_color="03c6ad" button_text_color="ffffff" ]</p> 
 <img src="https://themify.me/demo/themes/simple/files/2016/02/iMac-3-315x281.png" width="315" alt="iMac 3" srcset="https://themify.me/demo/themes/simple/files/2016/02/iMac-3-315x281.png 315w, https://themify.me/demo/themes/simple/files/2016/02/iMac-3-300x268.png 300w, https://themify.me/demo/themes/simple/files/2016/02/iMac-3.png 313w" sizes="(max-width: 315px) 100vw, 315px" /> 
 <h2>iMac</h2><p>Epretium condimentum tiam fermentum condimentumquam odio malesuada purus, elit ac accumsan. Proin cursus, lectus malesuada, et sodales diam erat velest.</p><p>[shopify_buy_button shop="themifytest.myshopify.com" embed_type="product" handle="imac" has_image="false" has_modal="false" redirect_to="checkout" buy_button_text="Get it now" button_background_color="03c6ad" button_text_color="ffffff" ]</p> 
 <img src="https://themify.me/demo/themes/simple/files/2016/02/leather-shoes-400x285.png" width="400" alt="leather shoes" srcset="https://themify.me/demo/themes/simple/files/2016/02/leather-shoes-400x285.png 400w, https://themify.me/demo/themes/simple/files/2016/02/leather-shoes-300x214.png 300w, https://themify.me/demo/themes/simple/files/2016/02/leather-shoes-315x225.png 315w, https://themify.me/demo/themes/simple/files/2016/02/leather-shoes.png 382w" sizes="(max-width: 400px) 100vw, 400px" /> 
 <h2>Leather Shoes</h2><p>Cras non ultricies nulla, quis varius orci. Nulla ac pellentesque eros, eu interdum leo. Phasellus non dui viverra, consectetur mauris ac, pharetra massa. Curabitur posuere posuere dolor.</p><p>[shopify_buy_button shop="themifytest.myshopify.com" embed_type="product" handle="womens-boot" has_image="false" has_modal="false" redirect_to="cart" buy_button_text="Add To Cart" button_background_color="03c6ad" button_text_color="ffffff"]</p> 
 <img src="https://themify.me/demo/themes/simple/files/2016/02/iphone-175x276.png" width="175" alt="iphone" srcset="https://themify.me/demo/themes/simple/files/2016/02/iphone-175x276.png 175w, https://themify.me/demo/themes/simple/files/2016/02/iphone.png 173w" sizes="(max-width: 175px) 100vw, 175px" /> 
 <h2>iPhone 6</h2><p>[shopify_buy_button shop="themifytest.myshopify.com" embed_type="product" handle="iphone-6" has_image="false" has_modal="false" redirect_to="checkout" buy_button_text="Checkout Now" button_background_color="03c6ad" button_text_color="ffffff"]</p> 
 <a href="https://themify.me/demo/themes/simple/files/2016/02/iphone-6-658844_1280-1-1024x682.jpg" > <img src="https://themify.me/demo/themes/simple/files/2016/03/iphone-6-658844_1280-1-230x230.png" width="230" height="230" alt="iphone-6-658844_1280-1" srcset="https://themify.me/demo/themes/simple/files/2016/03/iphone-6-658844_1280-1.png 230w, https://themify.me/demo/themes/simple/files/2016/03/iphone-6-658844_1280-1-150x150.png 150w" sizes="(max-width: 230px) 100vw, 230px" /> </a> 
 <a href="https://themify.me/demo/themes/simple/files/2016/02/iphone-926118_1280-1-1024x682.jpg" > <img src="https://themify.me/demo/themes/simple/files/2016/03/iphone-926118_1280-1-230x230.png" width="230" height="230" alt="" /> </a> 
 <a href="https://themify.me/demo/themes/simple/files/2016/02/mobile-791164_1280-1024x682.jpg" > <img src="https://themify.me/demo/themes/simple/files/2016/03/mobile-791164_1280-230x230.png" width="230" height="230" alt="" /> </a> 
 <a href="https://themify.me/demo/themes/simple/files/2016/02/iphone-1067989_1280-1024x768.jpg" > <img src="https://themify.me/demo/themes/simple/files/2016/03/iphone-1067989_1280-230x230.png" width="230" height="230" alt="" /> </a> 
 <a href="https://themify.me/demo/themes/simple/files/2016/02/apple-1034304_1280-1024x768.jpg" > <img src="https://themify.me/demo/themes/simple/files/2016/03/apple-1034304_1280-230x230.png" width="230" height="230" alt="" /> </a> 
 <a href="https://themify.me/demo/themes/simple/files/2016/02/iphone-518101_1280-1-1024x682.jpg" > <img src="https://themify.me/demo/themes/simple/files/2016/03/iphone-518101_1280-1-230x230.png" width="230" height="230" alt="" /> </a> 
 <a href="https://themify.me/demo/themes/simple/files/2016/02/girl-925284_1280-1024x682.jpg" > <img src="https://themify.me/demo/themes/simple/files/2016/03/girl-925284_1280-230x230.png" width="230" height="230" alt="" /> </a> 
 <a href="https://themify.me/demo/themes/simple/files/2016/02/phone-762550_1280-1024x682.jpg" > <img src="https://themify.me/demo/themes/simple/files/2016/03/phone-762550_1280-230x230.png" width="230" height="230" alt="" /> </a> 
 <a href="https://themify.me/demo/themes/simple/files/2016/02/table-1100265_1280-1024x767.jpg" > <img src="https://themify.me/demo/themes/simple/files/2016/03/table-1100265_1280-230x230.png" width="230" height="230" alt="" /> </a><!--/themify_builder_static-->',
  'post_title' => 'Shop',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2019-03-13 23:31:00',
  'post_modified_gmt' => '2019-03-13 23:31:00',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?page_id=90',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'header_wrap' => 'transparent',
    'background_repeat' => 'fullcover',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'media_position' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"d274b7c\\",\\"row_order\\":\\"0\\",\\"cols\\":[{\\"element_id\\":\\"39b7897\\",\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"3d23286\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Shopify + Themify <\\\\/h1><p>Simple is a free theme to make Shopify ecommerce sites with WordPress.<\\\\/p>\\",\\"font_color\\":\\"ffffff_1.00\\",\\"font_size\\":\\"1.1\\",\\"font_size_unit\\":\\"em\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"15\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"15\\",\\"padding_left_unit\\":\\"%\\",\\"animation_effect\\":\\"fadeInUp\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"7e9910f\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>[themify_button link=\\\\\\\\\\\\\\"https:\\\\/\\\\/themify.me\\\\/themes\\\\/simple\\\\\\\\\\\\\\" style=\\\\\\\\\\\\\\"large rounded white outline\\\\\\\\\\\\\\"]Download[\\\\/themify_button]<\\\\/p>\\",\\"font_color\\":\\"ffffff_1.00\\",\\"font_size\\":\\"1.1\\",\\"font_size_unit\\":\\"em\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"15\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"15\\",\\"padding_left_unit\\":\\"%\\",\\"animation_effect\\":\\"fadeInUp\\",\\"animation_effect_delay\\":\\".5\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"c546d70\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"0\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"icon_size\\":\\"xlarge\\",\\"icon_style\\":\\"none\\",\\"icon_arrangement\\":\\"icon_horizontal\\",\\"content_icon\\":[{\\"icon\\":\\"fa-angle-double-down\\",\\"link\\":\\"#products\\",\\"link_options\\":\\"regular\\",\\"new_window\\":\\"\\",\\"icon_color_bg\\":\\"\\"}],\\"animation_effect\\":\\"bounce\\",\\"animation_effect_repeat\\":\\"5\\",\\"icon_position\\":\\"icon_position_left\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"row_height\\":\\"fullheight\\",\\"custom_css_row\\":\\"full-height\\",\\"background_type\\":\\"image\\",\\"background_video\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/wp-content\\\\/blogs.dir\\\\/83\\\\/files\\\\/2016\\\\/02\\\\/girl-street.mp4\\",\\"background_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/model-600238_1920-1024x683.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-center\\",\\"background_color\\":\\"000000_1.00\\",\\"cover_color-type\\":\\"color\\",\\"cover_color\\":\\"000000_0.38\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color_hover\\":\\"000000_0.69\\",\\"text_align\\":\\"center\\",\\"link_color\\":\\"ffffff_1.00\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"a7adc75\\",\\"row_order\\":\\"1\\",\\"cols\\":[{\\"element_id\\":\\"c83034e\\",\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"d7d9dbb\\",\\"row_order\\":\\"0\\",\\"cols\\":[{\\"element_id\\":\\"96cfef1\\",\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2a721ad\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/ripped-jeans.png\\",\\"width_image\\":\\"445\\",\\"animation_effect\\":\\"fadeIn\\"}}]},{\\"element_id\\":\\"6f4a4da\\",\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"c9f6e91\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\\\\\\\\\"text-align: left;\\\\\\\\\\\\\\">Ripped Jeans<\\\\/h2><p style=\\\\\\\\\\\\\\"text-align: left;\\\\\\\\\\\\\\">Cras non ultricies nulla, quis varius orci. Nulla ac pellentesque eros, eu interdum leo. Phasellus non dui viverra, consectetur mauris ac, pharetra massa.<\\\\/p><p style=\\\\\\\\\\\\\\"text-align: left;\\\\\\\\\\\\\\">[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"product\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"ripped-jeans\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"cart\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Add To Cart\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"03c6ad\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"ffffff\\\\\\\\\\\\\\"]<\\\\/p>\\",\\"font_color\\":\\"ffffff\\",\\"text_align\\":\\"left\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_left_unit\\":\\"%\\"}}]}]}]}],\\"styling\\":{\\"row_anchor\\":\\"products\\",\\"background_type\\":\\"image\\",\\"background_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/jeans-1024x478.jpg\\",\\"background_repeat\\":\\"builder-parallax-scrolling\\",\\"background_position\\":\\"center-center\\",\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"347d708\\",\\"row_order\\":\\"2\\",\\"cols\\":[{\\"element_id\\":\\"fcb3a4b\\",\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2207602\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/smartwatch.png\\",\\"width_image\\":\\"315\\",\\"padding_top\\":\\"20\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0dd051a\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Smart Watch<\\\\/h2><p>Epretium condimentum tiam fermentum condimentum elit ac accumsan. Proin cursus, lectus malesuada , quam odio malesuada purus, et sodales diam erat velest.<\\\\/p><p>[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"product\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"smart-watch\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"checkout\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Buy Now\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"03c6ad\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"ffffff\\\\\\\\\\\\\\" ]<\\\\/p>\\",\\"text_align\\":\\"left\\",\\"padding_bottom\\":\\"17\\",\\"padding_bottom_unit\\":\\"%\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/smartwatch-bg-1.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"text_align\\":\\"center\\",\\"padding_right\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_left_unit\\":\\"%\\"}},{\\"element_id\\":\\"a8baf90\\",\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"46614dc\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/iMac-3.png\\",\\"width_image\\":\\"315\\",\\"padding_top\\":\\"19\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"31d8efb\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>iMac<\\\\/h2><p>Epretium condimentum tiam fermentum condimentumquam odio malesuada purus, elit ac accumsan. Proin cursus, lectus malesuada, et sodales diam erat velest.<\\\\/p><p>[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"product\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"imac\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"checkout\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Get it now\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"03c6ad\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"ffffff\\\\\\\\\\\\\\" ]<\\\\/p>\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"text_align\\":\\"left\\",\\"padding_bottom\\":\\"17\\",\\"padding_bottom_unit\\":\\"%\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/imac-bg.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"text_align\\":\\"center\\",\\"padding_right\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_left_unit\\":\\"%\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"ffffff_1.00\\",\\"link_color\\":\\"ffffff_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"63fae3e\\",\\"row_order\\":\\"3\\",\\"cols\\":[{\\"element_id\\":\\"b085f58\\",\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"c8a7089\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/leather-shoes.png\\",\\"width_image\\":\\"400\\",\\"padding_top\\":\\"35\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"20\\",\\"padding_bottom_unit\\":\\"%\\",\\"margin_bottom\\":\\"10\\",\\"margin_bottom_unit\\":\\"%\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"cover_color\\":\\"000000_0.59\\",\\"text_align\\":\\"center\\",\\"padding_right\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_left_unit\\":\\"%\\"}},{\\"element_id\\":\\"b531919\\",\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"28922ca\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Leather Shoes<\\\\/h2><p>Cras non ultricies nulla, quis varius orci. Nulla ac pellentesque eros, eu interdum leo. Phasellus non dui viverra, consectetur mauris ac, pharetra massa. Curabitur posuere posuere dolor.<\\\\/p><p>[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"product\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"womens-boot\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"cart\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Add To Cart\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"03c6ad\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"ffffff\\\\\\\\\\\\\\"]<\\\\/p>\\",\\"text_align\\":\\"left\\",\\"padding_top\\":\\"35\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"20\\",\\"padding_bottom_unit\\":\\"%\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"text_align\\":\\"left\\",\\"padding_right\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_left_unit\\":\\"%\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"background_type\\":\\"image\\",\\"background_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/leather-shoes-bg-1024x479.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-center\\",\\"font_color\\":\\"ffffff\\",\\"text_align\\":\\"center\\",\\"link_color\\":\\"ffffff\\",\\"padding_bottom_unit\\":\\"%\\"}},{\\"element_id\\":\\"b4c72dc\\",\\"row_order\\":\\"4\\",\\"cols\\":[{\\"element_id\\":\\"2c30976\\",\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3241606\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/iphone.png\\",\\"width_image\\":\\"175\\",\\"padding_top\\":\\"20\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ef7aa7e\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>iPhone 6<\\\\/h2><p>[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"product\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"iphone-6\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"checkout\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Checkout Now\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"03c6ad\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"ffffff\\\\\\\\\\\\\\"]<\\\\/p>\\",\\"text_align\\":\\"left\\",\\"padding_bottom\\":\\"10\\",\\"padding_bottom_unit\\":\\"%\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/03\\\\/iphonebg.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"text_align\\":\\"center\\",\\"padding_right\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_left_unit\\":\\"%\\"}},{\\"element_id\\":\\"1f80f18\\",\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"ee9a703\\",\\"row_order\\":\\"0\\",\\"cols\\":[{\\"element_id\\":\\"de1f325\\",\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"5ab0acd\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/03\\\\/iphone-6-658844_1280-1.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/iphone-6-658844_1280-1-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"8148060\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/03\\\\/iphone-926118_1280-1-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/iphone-926118_1280-1-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"49862b2\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/03\\\\/mobile-791164_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/mobile-791164_1280-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}]},{\\"element_id\\":\\"ea91ac4\\",\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"b2a8de2\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/03\\\\/iphone-1067989_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/iphone-1067989_1280-1024x768.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"9f29fd8\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/03\\\\/apple-1034304_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/apple-1034304_1280-1024x768.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"845e335\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/03\\\\/iphone-518101_1280-1-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/iphone-518101_1280-1-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}]},{\\"element_id\\":\\"80fe313\\",\\"column_order\\":\\"2\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"bb30777\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/03\\\\/girl-925284_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/girl-925284_1280-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3b6bf00\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/03\\\\/phone-762550_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/phone-762550_1280-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"f12ef2e\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/03\\\\/table-1100265_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https://themify.me/demo/themes/simple\\\\/files\\\\/2016\\\\/02\\\\/table-1100265_1280-1024x767.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}]}],\\"gutter\\":\\"gutter-none\\"}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_repeat\\":\\"fullcover\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"ffffff_1.00\\",\\"text_align\\":\\"center\\",\\"link_color\\":\\"ffffff_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"37116dc\\",\\"row_order\\":\\"5\\",\\"cols\\":[{\\"element_id\\":\\"ae7818c\\",\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full\\"}]}]',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 144,
  'post_date' => '2016-02-20 02:54:33',
  'post_date_gmt' => '2016-02-20 02:54:33',
  'post_content' => '',
  'post_title' => 'Blog',
  'post_excerpt' => '',
  'post_name' => 'blog',
  'post_modified' => '2017-08-23 03:13:26',
  'post_modified_gmt' => '2017-08-23 03:13:26',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?page_id=144',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'page_title_background_image' => 'https://themify.me/demo/themes/simple/files/2016/02/blog.jpg',
    'query_category' => '0',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'posts_per_page' => '6',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'media_position' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 154,
  'post_date' => '2016-02-23 19:02:38',
  'post_date_gmt' => '2016-02-23 19:02:38',
  'post_content' => '',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2017-08-23 03:13:25',
  'post_modified_gmt' => '2017-08-23 03:13:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?page_id=154',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'page_sub_heading' => 'Simple is a free theme to make Shopify ecommerce sites with WordPress.',
    'hide_page_title' => 'default',
    'header_wrap' => 'transparent',
    'background_repeat' => 'fullcover',
    'page_title_background_color' => '#5630c9',
    'page_title_background_image' => 'https://themify.me/demo/themes/simple/files/2016/02/jewellery-792085_1920-2.jpg',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'media_position' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>The Shopify Buy Button plugin allows you to embed Shopify products on any page. You can display both products and collections with the Shopify Buy Button code or use the Builder to design any product layout.</p>\\",\\"font_family\\":\\"default\\",\\"font_size\\":\\"1.5\\",\\"font_size_unit\\":\\"em\\",\\"line_height\\":\\"1.8\\",\\"line_height_unit\\":\\"em\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right\\":\\"7\\",\\"padding_right_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left\\":\\"7\\",\\"padding_left_unit\\":\\"%\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\"}},{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>[themify_button link=\\\\\\\\\\\\\\"https://themify.me/themes/simple\\\\\\\\\\\\\\" style=\\\\\\\\\\\\\\"large rounded green\\\\\\\\\\\\\\"]Download[/themify_button]</p>\\",\\"font_family\\":\\"default\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"animation_effect\\":\\"fadeInUp\\"}}],\\"styling\\":[]}],\\"styling\\":{\\"row_width\\":\\"\\",\\"row_height\\":\\"\\",\\"custom_css_row\\":\\"\\",\\"row_anchor\\":\\"\\",\\"background_type\\":\\"image\\",\\"background_slider\\":\\"\\",\\"background_slider_mode\\":\\"\\",\\"background_video\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_position\\":\\"\\",\\"background_color\\":\\"\\",\\"cover_color\\":\\"\\",\\"cover_color_hover\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"text_align\\":\\"center\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right\\":\\"\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom\\":\\"\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left\\":\\"\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top\\":\\"\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right\\":\\"\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom\\":\\"\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left\\":\\"\\",\\"margin_left_unit\\":\\"px\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_column\\":\\"\\",\\"animation_effect\\":\\"\\",\\"animation_effect_delay\\":\\"\\",\\"animation_effect_repeat\\":\\"\\"}},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col4-2 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https://themify.me/demo/themes/simple/files/2016/02/smartwatch.png\\",\\"appearance_image\\":\\"|\\",\\"auto_fullwidth\\":\\"|\\",\\"param_image\\":\\"|\\",\\"font_family\\":\\"default\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"animation_effect\\":\\"fadeIn\\"}}],\\"styling\\":[]},{\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col4-2 last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3 style=\\\\\\\\\\\\\\"text-align: left;\\\\\\\\\\\\\\">Custom Builder Layout</h3><p style=\\\\\\\\\\\\\\"text-align: left;\\\\\\\\\\\\\\">Phasellus non dui viverra, consectetur mauris ac, pharetra massa.</p><p>[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"product\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"smart-watch\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"cart\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Add To Cart\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"e27351\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"ffffff\\\\\\\\\\\\\\"] </p><p> </p>\\",\\"visibility_desktop\\":\\"show\\",\\"visibility_desktop_show\\":\\"show\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet\\":\\"show\\",\\"visibility_tablet_show\\":\\"show\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile\\":\\"show\\",\\"visibility_mobile_show\\":\\"show\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"font_family\\":\\"default\\",\\"text_align\\":\\"left\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top\\":\\"7\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":\\"|\\",\\"checkbox_padding_apply_all_padding\\":\\"padding\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":\\"|\\",\\"checkbox_margin_apply_all_margin\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"|\\",\\"checkbox_border_apply_all_border\\":\\"border\\"}}],\\"styling\\":[]}],\\"column_alignment\\":\\"\\",\\"styling\\":[]}],\\"styling\\":[]}],\\"styling\\":{\\"row_width\\":\\"\\",\\"row_height\\":\\"\\",\\"custom_css_row\\":\\"\\",\\"row_anchor\\":\\"\\",\\"background_type\\":\\"image\\",\\"background_slider\\":\\"\\",\\"background_slider_mode\\":\\"\\",\\"background_video\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_position\\":\\"\\",\\"background_color\\":\\"\\",\\"cover_color\\":\\"\\",\\"cover_color_hover\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"text_align\\":\\"left\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"30\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right\\":\\"\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom\\":\\"\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left\\":\\"\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top\\":\\"60\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right\\":\\"\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom\\":\\"\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left\\":\\"\\",\\"margin_left_unit\\":\\"px\\",\\"border_top_color\\":\\"eeeeee\\",\\"border_top_width\\":\\"1\\",\\"border_top_style\\":\\"solid\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_column\\":\\"\\",\\"animation_effect\\":\\"\\",\\"animation_effect_delay\\":\\"\\",\\"animation_effect_repeat\\":\\"\\"}},{\\"row_order\\":\\"2\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Products</h3>\\",\\"font_family\\":\\"default\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\"}},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col4-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"product\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"imac\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"true\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"checkout\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Buy Now\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" background_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"]</p>\\",\\"font_family\\":\\"default\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\"}}],\\"styling\\":[]},{\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"product\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"ripped-jeans\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"true\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"checkout\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Buy Now\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" background_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"]</p>\\",\\"font_family\\":\\"default\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\"}}],\\"styling\\":[]},{\\"column_order\\":\\"2\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"product\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"womens-boot\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"true\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"checkout\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Buy Now\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" background_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"]</p>\\",\\"font_family\\":\\"default\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\"}}],\\"styling\\":[]},{\\"column_order\\":\\"3\\",\\"grid_class\\":\\"col4-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"product\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"smart-watch\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"true\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"false\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"checkout\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Buy Now\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" background_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"]</p>\\",\\"font_family\\":\\"default\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\"}}],\\"styling\\":[]}],\\"column_alignment\\":\\"\\",\\"styling\\":[]}],\\"styling\\":[]}],\\"styling\\":{\\"row_width\\":\\"\\",\\"row_height\\":\\"\\",\\"custom_css_row\\":\\"\\",\\"row_anchor\\":\\"\\",\\"background_type\\":\\"image\\",\\"background_slider\\":\\"\\",\\"background_slider_mode\\":\\"\\",\\"background_video\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_position\\":\\"\\",\\"background_color\\":\\"\\",\\"cover_color\\":\\"\\",\\"cover_color_hover\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"text_align\\":\\"center\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"30\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right\\":\\"\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom\\":\\"\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left\\":\\"\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top\\":\\"60\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right\\":\\"\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom\\":\\"\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left\\":\\"\\",\\"margin_left_unit\\":\\"px\\",\\"border_top_color\\":\\"eeeeee\\",\\"border_top_width\\":\\"1\\",\\"border_top_style\\":\\"solid\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_column\\":\\"\\",\\"animation_effect\\":\\"\\",\\"animation_effect_delay\\":\\"\\",\\"animation_effect_repeat\\":\\"\\"}},{\\"row_order\\":\\"3\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Collection</h3><p>[shopify_buy_button shop=\\\\\\\\\\\\\\"themifytest.myshopify.com\\\\\\\\\\\\\\" embed_type=\\\\\\\\\\\\\\"collection\\\\\\\\\\\\\\" handle=\\\\\\\\\\\\\\"frontpage\\\\\\\\\\\\\\" has_image=\\\\\\\\\\\\\\"true\\\\\\\\\\\\\\" has_modal=\\\\\\\\\\\\\\"true\\\\\\\\\\\\\\" redirect_to=\\\\\\\\\\\\\\"modal\\\\\\\\\\\\\\" buy_button_text=\\\\\\\\\\\\\\"Buy Now\\\\\\\\\\\\\\" button_background_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" button_text_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" background_color=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"]</p>\\",\\"font_family\\":\\"default\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\"}}],\\"styling\\":[]}],\\"styling\\":{\\"row_width\\":\\"\\",\\"row_height\\":\\"\\",\\"custom_css_row\\":\\"\\",\\"row_anchor\\":\\"\\",\\"background_type\\":\\"image\\",\\"background_slider\\":\\"\\",\\"background_slider_mode\\":\\"\\",\\"background_video\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_position\\":\\"\\",\\"background_color\\":\\"\\",\\"cover_color\\":\\"\\",\\"cover_color_hover\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"text_align\\":\\"center\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"30\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right\\":\\"\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom\\":\\"\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left\\":\\"\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top\\":\\"60\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right\\":\\"\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom\\":\\"\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left\\":\\"\\",\\"margin_left_unit\\":\\"px\\",\\"border_top_color\\":\\"eee\\",\\"border_top_width\\":\\"1\\",\\"border_top_style\\":\\"solid\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_column\\":\\"\\",\\"animation_effect\\":\\"\\",\\"animation_effect_delay\\":\\"\\",\\"animation_effect_repeat\\":\\"\\"}},{\\"row_order\\":\\"4\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[]}],\\"styling\\":[]}]',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2339,
  'post_date' => '2014-06-24 01:28:36',
  'post_date_gmt' => '2014-06-24 01:28:36',
  'post_content' => '',
  'post_title' => 'News',
  'post_excerpt' => '',
  'post_name' => 'news',
  'post_modified' => '2014-06-24 01:28:36',
  'post_modified_gmt' => '2014-06-24 01:28:36',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/?post_type=tbuilder_layout&amp;p=2339',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2337,
  'post_date' => '2014-06-24 01:02:31',
  'post_date_gmt' => '2014-06-24 01:02:31',
  'post_content' => '',
  'post_title' => 'Portfolio',
  'post_excerpt' => '',
  'post_name' => 'portfolio',
  'post_modified' => '2014-06-24 01:02:31',
  'post_modified_gmt' => '2014-06-24 01:02:31',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/?post_type=tbuilder_layout&amp;p=2337',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2336,
  'post_date' => '2014-06-24 00:47:41',
  'post_date_gmt' => '2014-06-24 00:47:41',
  'post_content' => '',
  'post_title' => 'Product Single',
  'post_excerpt' => '',
  'post_name' => 'product-single',
  'post_modified' => '2014-06-24 00:47:41',
  'post_modified_gmt' => '2014-06-24 00:47:41',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/?post_type=tbuilder_layout&amp;p=2336',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2333,
  'post_date' => '2014-06-24 00:03:16',
  'post_date_gmt' => '2014-06-24 00:03:16',
  'post_content' => '',
  'post_title' => 'Agency',
  'post_excerpt' => '',
  'post_name' => 'agency',
  'post_modified' => '2014-06-24 00:03:16',
  'post_modified_gmt' => '2014-06-24 00:03:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/tbuilder-layout/product-landing-copy/',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
themify_process_post_import( $post );


$post = array (
  'ID' => 315,
  'post_date' => '2014-06-23 23:39:39',
  'post_date_gmt' => '2014-06-23 23:39:39',
  'post_content' => '',
  'post_title' => 'Magazine',
  'post_excerpt' => '',
  'post_name' => 'magazine',
  'post_modified' => '2014-06-23 23:39:39',
  'post_modified_gmt' => '2014-06-23 23:39:39',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/?post_type=tbuilder_layout&amp;p=79',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
themify_process_post_import( $post );


$post = array (
  'ID' => 314,
  'post_date' => '2014-06-21 00:06:16',
  'post_date_gmt' => '2014-06-21 00:06:16',
  'post_content' => '',
  'post_title' => 'Photo Page',
  'post_excerpt' => '',
  'post_name' => 'photo-page',
  'post_modified' => '2014-06-21 00:06:16',
  'post_modified_gmt' => '2014-06-21 00:06:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/tbuilder-layout/product-landing-2-copy/',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
themify_process_post_import( $post );


$post = array (
  'ID' => 313,
  'post_date' => '2014-06-20 22:33:10',
  'post_date_gmt' => '2014-06-20 22:33:10',
  'post_content' => '',
  'post_title' => 'Product Landing 2',
  'post_excerpt' => '',
  'post_name' => 'product-landing-2',
  'post_modified' => '2014-06-20 22:33:10',
  'post_modified_gmt' => '2014-06-20 22:33:10',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/tbuilder-layout/product-landing-copy/',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
themify_process_post_import( $post );


$post = array (
  'ID' => 312,
  'post_date' => '2014-06-17 23:11:13',
  'post_date_gmt' => '2014-06-17 23:11:13',
  'post_content' => '',
  'post_title' => 'Product Landing',
  'post_excerpt' => '',
  'post_name' => 'product-landing',
  'post_modified' => '2014-06-17 23:11:13',
  'post_modified_gmt' => '2014-06-17 23:11:13',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/?post_type=tbuilder_layout&amp;p=6',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
themify_process_post_import( $post );


$post = array (
  'ID' => 147,
  'post_date' => '2016-02-20 02:56:16',
  'post_date_gmt' => '2016-02-20 02:56:16',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '147',
  'post_modified' => '2016-02-23 19:03:03',
  'post_modified_gmt' => '2016-02-23 19:03:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=147',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '90',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-menu',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 156,
  'post_date' => '2016-02-23 19:03:03',
  'post_date_gmt' => '2016-02-23 19:03:03',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '156',
  'post_modified' => '2016-02-23 19:03:03',
  'post_modified_gmt' => '2016-02-23 19:03:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=156',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '154',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-menu',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 146,
  'post_date' => '2016-02-20 02:56:16',
  'post_date_gmt' => '2016-02-20 02:56:16',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '146',
  'post_modified' => '2016-02-23 19:03:03',
  'post_modified_gmt' => '2016-02-23 19:03:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=146',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '144',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-menu',
  ),
);
themify_process_post_import( $post );



function themify_import_get_term_id_from_slug( $slug ) {
	$menu = get_term_by( "slug", $slug, "nav_menu" );
	return is_wp_error( $menu ) ? 0 : (int) $menu->term_id;
}

	$widgets = get_option( "widget_search" );
$widgets[1002] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1003] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1004] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1005] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1006] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1007] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1008] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1009] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-large',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );



$sidebars_widgets = array (
  'sidebar-main' => 
  array (
    0 => 'search-1002',
    1 => 'recent-posts-1003',
    2 => 'recent-comments-1004',
    3 => 'archives-1005',
    4 => 'categories-1006',
    5 => 'meta-1007',
  ),
  'social-widget' => 
  array (
    0 => 'themify-social-links-1008',
  ),
  'footer-social-widget' => 
  array (
    0 => 'themify-social-links-1009',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-menu" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );


$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			
	ob_start(); ?>a:60:{s:21:"setting-webfonts_list";s:11:"recommended";s:22:"setting-default_layout";s:12:"sidebar-none";s:27:"setting-default_post_layout";s:9:"list-post";s:30:"setting-default_layout_display";s:7:"content";s:25:"setting-default_more_text";s:4:"More";s:21:"setting-index_orderby";s:4:"date";s:19:"setting-index_order";s:4:"DESC";s:30:"setting-default_media_position";s:5:"above";s:31:"setting-image_post_feature_size";s:5:"blank";s:32:"setting-default_page_post_layout";s:12:"sidebar-none";s:38:"setting-image_post_single_feature_size";s:5:"blank";s:27:"setting-default_page_layout";s:12:"sidebar-none";s:53:"setting-customizer_responsive_design_tablet_landscape";s:4:"1280";s:43:"setting-customizer_responsive_design_tablet";s:3:"768";s:43:"setting-customizer_responsive_design_mobile";s:3:"680";s:33:"setting-mobile_menu_trigger_point";s:4:"1200";s:24:"setting-gallery_lightbox";s:8:"lightbox";s:26:"setting-page_builder_cache";s:2:"on";s:27:"setting-page_builder_expiry";s:1:"2";s:19:"setting-entries_nav";s:8:"numbered";s:22:"setting-footer_widgets";s:17:"footerwidget-3col";s:27:"setting-global_feature_size";s:5:"blank";s:22:"setting-link_icon_type";s:9:"font-icon";s:32:"setting-link_type_themify-link-0";s:10:"image-icon";s:33:"setting-link_title_themify-link-0";s:7:"Twitter";s:31:"setting-link_img_themify-link-0";s:101:"https://themify.me/demo/themes/simple/wp-content/themes/themify-simple/themify/img/social/twitter.png";s:32:"setting-link_type_themify-link-1";s:10:"image-icon";s:33:"setting-link_title_themify-link-1";s:8:"Facebook";s:31:"setting-link_img_themify-link-1";s:102:"https://themify.me/demo/themes/simple/wp-content/themes/themify-simple/themify/img/social/facebook.png";s:32:"setting-link_type_themify-link-2";s:10:"image-icon";s:33:"setting-link_title_themify-link-2";s:7:"Google+";s:31:"setting-link_img_themify-link-2";s:105:"https://themify.me/demo/themes/simple/wp-content/themes/themify-simple/themify/img/social/google-plus.png";s:32:"setting-link_type_themify-link-3";s:10:"image-icon";s:33:"setting-link_title_themify-link-3";s:7:"YouTube";s:31:"setting-link_img_themify-link-3";s:101:"https://themify.me/demo/themes/simple/wp-content/themes/themify-simple/themify/img/social/youtube.png";s:32:"setting-link_type_themify-link-4";s:10:"image-icon";s:33:"setting-link_title_themify-link-4";s:9:"Pinterest";s:31:"setting-link_img_themify-link-4";s:103:"https://themify.me/demo/themes/simple/wp-content/themes/themify-simple/themify/img/social/pinterest.png";s:32:"setting-link_type_themify-link-6";s:9:"font-icon";s:33:"setting-link_title_themify-link-6";s:8:"Facebook";s:32:"setting-link_link_themify-link-6";s:32:"https://www.facebook.com/themify";s:33:"setting-link_ficon_themify-link-6";s:11:"fa-facebook";s:32:"setting-link_type_themify-link-5";s:9:"font-icon";s:33:"setting-link_title_themify-link-5";s:7:"Twitter";s:32:"setting-link_link_themify-link-5";s:27:"https://twitter.com/themify";s:33:"setting-link_ficon_themify-link-5";s:10:"fa-twitter";s:32:"setting-link_type_themify-link-7";s:9:"font-icon";s:33:"setting-link_title_themify-link-7";s:7:"Google+";s:33:"setting-link_ficon_themify-link-7";s:14:"fa-google-plus";s:32:"setting-link_type_themify-link-8";s:9:"font-icon";s:33:"setting-link_title_themify-link-8";s:7:"YouTube";s:32:"setting-link_link_themify-link-8";s:39:"https://www.youtube.com/user/themifyme/";s:33:"setting-link_ficon_themify-link-8";s:10:"fa-youtube";s:32:"setting-link_type_themify-link-9";s:9:"font-icon";s:33:"setting-link_title_themify-link-9";s:9:"Pinterest";s:33:"setting-link_ficon_themify-link-9";s:12:"fa-pinterest";s:22:"setting-link_field_ids";s:341:"{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-6":"themify-link-6","themify-link-5":"themify-link-5","themify-link-7":"themify-link-7","themify-link-8":"themify-link-8","themify-link-9":"themify-link-9"}";s:23:"setting-link_field_hash";s:2:"10";s:30:"setting-page_builder_is_active";s:6:"enable";s:46:"setting-page_builder_animation_parallax_scroll";s:6:"mobile";}<?php $themify_data = unserialize( ob_get_clean() );

	// fix the weird way "skin" is saved
	if( isset( $themify_data['skin'] ) ) {
		$parsed_skin = parse_url( $themify_data['skin'], PHP_URL_PATH );
		$basedir_skin = basename( dirname( $parsed_skin ) );
		$themify_data['skin'] = trailingslashit( get_template_directory_uri() ) . 'skins/' . $basedir_skin . '/style.css';
	}

	themify_set_data( $themify_data );
	
}
themify_do_demo_import();